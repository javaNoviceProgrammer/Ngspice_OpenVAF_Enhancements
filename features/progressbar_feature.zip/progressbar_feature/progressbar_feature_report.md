## What the feature is

A usability improvement to ngspice's console output: the throttled
**"Reference value"** status line printed during a swept analysis (DC / AC /
transient / noise) now carries a **live progress bar and percentage**, so you
can see not just *where* the sweep is but *how far along* it is.

ngspice already redrew, in place (via carriage return) every 0.25 s, a line
showing the current sweep variable:

```
 Reference value :  5.91926e-04
```

With this feature it becomes:

```
 Reference value :  5.91926e-04  [==================      ]  74%
```

The bar is a fixed 24-character width so the in-place redraw never leaves stale
characters; it is emitted through the same throttled, non-background
(`!ft_norefprint && !cp_background`) path as the original line, and writes
**only to the status line on stdout** — never into the rawfile or `wrdata`
output. Analyses with no well-defined span (operating point, transfer
function, …) keep the original plain line — no bar, no misinformation.

At the end of a swept run the bar is always completed to **100%** (E-184): the throttled per-point print almost always skips the final point, so a forced end-of-run print reprints the bar full using the sweep's true endpoint.

## The completion fraction

The 0–1 fraction is computed per analysis in `outp_progress_frac()`, from data
already on the circuit / job:

| Analysis | Fraction |
|----------|----------|
| **transient** | elapsed time over the run: `(CKTtime − CKTinitTime) / (CKTfinalTime − CKTinitTime)` |
| **AC**, **noise** | the current frequency's place in the band — linear for `lin`, logarithmic for `dec`/`oct`: `log(f/f₀) / log(f₁/f₀)` |
| **DC** | accepted-point count over the product of the nested sweep step counts (correct for multi-source `.dc` nesting) |

Anything else returns −1 and prints the plain line.

## Files changed

The feature lives entirely in one shared front-end file.

| File | Kind | Change |
|------|------|--------|
| `ngspice-46/src/frontend/outitf.c` | modified | adds `outp_progress_frac()` (per-analysis 0–1 fraction) and `outp_print_reference()` (the status line, with the bar); the six "Reference value" print sites now call the helper; includes `acdefs.h` / `trcvdefs.h` for the AC/DC job structs (+95 lines) |
| `examples/progressbar_examples/` | — | `progressbar_demo.cir`, `verify_progressbar.py` (the verifying suite) |

`outitf.c` is ngspice's core output interface and carries much else besides
this feature — the feature's own code is the two functions plus the includes
and the six call sites.

### The heart of the feature

```c
static double
outp_progress_frac(runDesc *run, double refval)
{
    ...
    if (strcmp(nm, "TRAN") == 0) {
        double span = ckt->CKTfinalTime - ckt->CKTinitTime;
        if (span > 0.0)
            return (ckt->CKTtime - ckt->CKTinitTime) / span;
    } else if (strcmp(nm, "AC") == 0) {          /* NOISE is analogous */
        ACAN *ac = (ACAN *) job;
        double f0 = ac->ACstartFreq, f1 = ac->ACstopFreq;
        if (ac->ACstepType == LINEAR)   return (refval - f0) / (f1 - f0);
        else /* dec/oct */              return log(refval / f0) / log(f1 / f0);
    } else if (strcmp(nm, "DC") == 0) {
        TRCV *dc = (TRCV *) job;                 /* product of nested step counts */
        ...
        return (double) run->pointCount / total;
    }
    return -1.0;                                  /* op / tf / ... : no bar */
}
```

`outp_print_reference()` then draws the bar when the fraction is known
(clamped to ≤ 100 %, redrawn in place with `\r` at constant width), and falls
back to the plain line otherwise. It also stays silent while the built-in
optimizer is iterating ([Enhancement-130](https://github.com/javaNoviceProgrammer/Ngspice_OpenVAF_Enhancements/blob/main/enhancements_doc/Enhancement-130.md)'s `ft_optimizing` guard).

## Enhancement history

| Enhancement | What it added |
|-------------|---------------|
| **[E-129](https://github.com/javaNoviceProgrammer/Ngspice_OpenVAF_Enhancements/blob/main/enhancements_doc/Enhancement-129.md)** | the sweep progress bar (this feature) — bar + percentage on the "Reference value" line for DC / AC / transient / noise |
| **[E-184](https://github.com/javaNoviceProgrammer/Ngspice_OpenVAF_Enhancements/blob/main/enhancements_doc/Enhancement-184.md)** | the bar now always reaches **100%** at end of run (the throttled per-point print skipped the final point; a forced end-of-run print completes it) |

The optimizer-quiet guard in `outp_print_reference()` is shared with
**[E-130](https://github.com/javaNoviceProgrammer/Ngspice_OpenVAF_Enhancements/blob/main/enhancements_doc/Enhancement-130.md)** (the built-in `optimize` command), which suppresses the status line
during its inner analysis runs.

## Verification

`examples/progressbar_examples/verify_progressbar.py` — 22 checks: it runs a
long-enough sweep of each kind (past the 0.25 s throttle), decodes the
carriage-return-updated line, and verifies the bar (`[…] NN%`) is emitted for
tran / AC / DC / noise; the printed percentage matches the analytic sweep
fraction at that reference value (within 0.5 % — transient linear-in-time,
AC/noise log-in-frequency, DC linear-in-source); the bar fill length is
proportional to the percentage; the percentages are monotone and reach **exactly** 100 % at end of run (E-184);
and an operating-point run prints **no** bar (and still returns its result).
It is a front-end output feature independent of the linear solver, so it is
checked once (the bytes are identical under Sparse and KLU).

## How it works

The six sites in `outitf.c` that printed the throttled "Reference value" line —
across the transient, AC, DC and noise output paths — now call
`outp_print_reference(run, refval)`. That helper asks `outp_progress_frac()`
for the sweep completion (dispatching on the current job's analysis name), and
either draws the bar or prints the plain line, redrawing in place. Because the
whole thing hangs off the pre-existing throttled print path, quiet/background
runs (`-o`, `cp_background`) are unaffected.

## Archive contents

```
progressbar_feature_report.md                    this report
progressbar_feature_report.pdf                    PDF rendering
build_progressbar_pdf.py                          regenerates the PDF (pandoc + xelatex)
ngspice-46/src/frontend/outitf.c                 (modified — carries the rest of the output interface too)
examples/_setup.py                               dual-solver test harness (imported by the suite)
examples/progressbar_examples/progressbar_demo.cir
examples/progressbar_examples/verify_progressbar.py
```
